type Product @model {
  id: ID!
  dynamicSlug: String!
  productName: String!
}
